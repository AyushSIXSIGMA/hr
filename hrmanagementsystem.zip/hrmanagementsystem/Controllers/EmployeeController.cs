﻿using Microsoft.AspNetCore.Mvc;
using hrmanagementsystem.Data;
using System.Data;

namespace hrmanagementsystem.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly DbHelper _db;

        public EmployeeController(DbHelper db)
        {
            _db = db;
        }

        // LIST
        public IActionResult Index()
        {
            DataTable dt = _db.GetEmployees();
            return View(dt);
        }

        // CREATE - GET
        public IActionResult Create()
        {
            return View();
        }

        // CREATE - POST
        [HttpPost]
        public IActionResult Create(string fullName, string email, decimal salary)
        {
            _db.InsertEmployee(fullName, email, salary);
            return RedirectToAction("Index");
        }

        // EDIT - GET
        public IActionResult Edit(int id)
        {
            DataRow row = _db.GetEmployeeById(id);
            return View(row);
        }

        // EDIT - POST
        [HttpPost]
        public IActionResult Edit(int empId, string fullName, string email, decimal salary)
        {
            _db.UpdateEmployee(empId, fullName, email, salary);
            return RedirectToAction("Index");
        }

        // DELETE
        public IActionResult Delete(int id)
        {
            _db.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}
