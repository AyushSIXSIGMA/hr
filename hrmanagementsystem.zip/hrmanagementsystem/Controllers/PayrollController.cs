﻿using Microsoft.AspNetCore.Mvc;
using hrmanagementsystem.Data;
using System.Data;

namespace hrmanagementsystem.Controllers
{
    public class PayrollController : Controller
    {
        private readonly DbHelper _db;

        public PayrollController(DbHelper db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            DataTable dt = _db.GetPayroll(); // 🔥 dynamic from Employee table
            return View(dt);
        }
    }
}
