using Microsoft.AspNetCore.Mvc;
using hrmanagementsystem.Data;
using System.Data;

namespace hrmanagementsystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly DbHelper _db;

        public HomeController(DbHelper db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            // ===== TOP STATS =====
            ViewBag.TotalEmployees = _db.GetTotalEmployees();
            ViewBag.TotalPayroll = _db.GetTotalPayroll();

            // ===== CHART DATA =====
            DataTable salaryChartData = _db.GetSalaryChartData();         
            DataTable empPerDeptData = _db.GetEmployeesPerDepartment();    

            ViewBag.EmpPerDept = empPerDeptData;

            return View(salaryChartData);
        }
    }
}
