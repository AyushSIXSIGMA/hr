﻿using hrmanagementsystem.Data;
using Microsoft.AspNetCore.Mvc;

public class DashboardController : Controller
{
    private readonly DbHelper _db;

    public DashboardController(DbHelper db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        ViewBag.TotalEmployees = _db.GetTotalEmployees();
        ViewBag.TotalPayroll = _db.GetTotalPayroll();

        ViewBag.MaxSalary = _db.GetMaxSalary();   // you must add this method
        ViewBag.MinSalary = _db.GetMinSalary();   // you must add this method

        ViewBag.EmpPerDept = _db.GetEmployeesPerDepartment(); // DataTable

        var salaryTable = _db.GetSalaryChartData(); // DataTable (FullName, Salary)

        return View(salaryTable);
    }
}
