﻿using Microsoft.AspNetCore.Mvc;
using hrmanagementsystem.Data;
using hrmanagementsystem.Models;
using System.Data;

namespace hrmanagementsystem.Controllers
{
    public class LeavesController : Controller
    {
        private readonly DbHelper _db;

        public LeavesController(DbHelper db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            DataTable dt = _db.GetAllLeaves();   // we’ll add this method next
            return View(dt);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Leave leave)
        {
            if (ModelState.IsValid)
            {
                _db.InsertLeave(leave);   // we’ll add this method next
                return RedirectToAction("Index");
            }
            return View(leave);
        }
    }
}
