﻿using hrmanagementsystem.Data;
using hrmanagementsystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace hrmanagementsystem.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly DbHelper _db;

        public DepartmentController(DbHelper db)
        {
            _db = db;
        }

        // LIST
        public IActionResult Index()
        {
            var list = _db.GetAllDepartments();
            return View(list);
        }

        // CREATE
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Department dept)
        {
            if (ModelState.IsValid)
            {
                _db.AddDepartment(dept);
                return RedirectToAction("Index");
            }
            return View(dept);
        }

        // EDIT
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var dept = _db.GetDepartmentById(id);
            if (dept == null) return NotFound();
            return View(dept);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Department dept)
        {
            if (ModelState.IsValid)
            {
                _db.UpdateDepartment(dept);
                return RedirectToAction("Index");
            }
            return View(dept);
        }

        // DELETE
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var dept = _db.GetDepartmentById(id);
            if (dept == null) return NotFound();
            return View(dept);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _db.DeleteDepartment(id);
            return RedirectToAction("Index");
        }
    }
}
