﻿using hrmanagementsystem.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace hrmanagementsystem.Data
{
    public class DbHelper
    {
        private readonly string _connectionString;

        public DbHelper(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // =========================
        // EMPLOYEE METHODS
        // =========================

        public DataTable GetEmployees(string? search = null)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                SELECT EmpId, FullName, Email, Salary, DeptId
                FROM Employee
                WHERE (@search IS NULL OR FullName LIKE @search OR Email LIKE @search)
                ORDER BY EmpId ASC";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    if (string.IsNullOrEmpty(search))
                        cmd.Parameters.AddWithValue("@search", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@search", "%" + search + "%");

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public void InsertEmployee(string fullName, string email, decimal salary, int? deptId = null)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                INSERT INTO Employee (FullName, Email, Salary, DeptId) 
                VALUES (@FullName, @Email, @Salary, @DeptId)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Salary", salary);
                    cmd.Parameters.AddWithValue("@DeptId", (object?)deptId ?? DBNull.Value);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataRow? GetEmployeeById(int id)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT EmpId, FullName, Email, Salary, DeptId FROM Employee WHERE EmpId = @Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }

            if (dt.Rows.Count > 0)
                return dt.Rows[0];

            return null;
        }

        public void UpdateEmployee(int empId, string fullName, string email, decimal salary, int? deptId = null)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                UPDATE Employee 
                SET FullName = @FullName, 
                    Email = @Email, 
                    Salary = @Salary,
                    DeptId = @DeptId
                WHERE EmpId = @EmpId";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Salary", salary);
                    cmd.Parameters.AddWithValue("@DeptId", (object?)deptId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmpId", empId);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteEmployee(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "DELETE FROM Employee WHERE EmpId = @Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // =========================
        // DASHBOARD METHODS
        // =========================

        public int GetTotalEmployees()
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT COUNT(*) FROM Employee";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                return (int)cmd.ExecuteScalar();
            }
        }

        public decimal GetTotalPayroll()
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT ISNULL(SUM(Salary), 0) FROM Employee";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }

        public DataTable GetSalaryChartData()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT FullName, Salary FROM Employee ORDER BY EmpId ASC";
                using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                {
                    da.Fill(dt);
                }
            }

            return dt;
        }

        public DataTable GetRecentEmployees()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                SELECT TOP 5 EmpId, FullName, Email, Salary 
                FROM Employee 
                ORDER BY EmpId DESC";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.Fill(dt);
            }

            return dt;
        }

        public DataTable GetEmployeesPerDepartment()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                SELECT d.Name AS DepartmentName, COUNT(e.EmpId) AS TotalEmployees
                FROM Departments d
                LEFT JOIN Employee e ON e.DeptId = d.Id
                GROUP BY d.Name";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.Fill(dt);
            }

            return dt;
        }

        // =========================
        // DEPARTMENT METHODS
        // =========================

        public List<Department> GetAllDepartments()
        {
            List<Department> list = new List<Department>();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT Id, Name, Description FROM Departments", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Department d = new Department
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"].ToString()!,
                        Description = reader["Description"]?.ToString()
                    };

                    list.Add(d);
                }
            }

            return list;
        }

        public Department? GetDepartmentById(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Departments WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Id", id);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return new Department
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"].ToString()!,
                        Description = reader["Description"]?.ToString()
                    };
                }
            }
            return null;
        }

        public void AddDepartment(Department dept)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Departments (Name, Description) VALUES (@Name, @Description)", con);

                cmd.Parameters.AddWithValue("@Name", dept.Name);
                cmd.Parameters.AddWithValue("@Description", dept.Description ?? "");

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateDepartment(Department dept)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "UPDATE Departments SET Name=@Name, Description=@Description WHERE Id=@Id";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Id", dept.Id);
                cmd.Parameters.AddWithValue("@Name", dept.Name);
                cmd.Parameters.AddWithValue("@Description", dept.Description ?? "");

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteDepartment(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "DELETE FROM Departments WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Id", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public decimal GetMaxSalary()
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT ISNULL(MAX(Salary),0) FROM Employee";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }


        public decimal GetMinSalary()
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT ISNULL(MIN(Salary),0) FROM Employee";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }

        public DataTable GetAllLeaves()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Leaves ORDER BY Id DESC";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }

            return dt;
        }


        public void InsertLeave(hrmanagementsystem.Models.Leave leave)
        {
            string query = @"INSERT INTO Leaves (EmployeeName, FromDate, ToDate, Reason, Status)
                     VALUES (@EmployeeName, @FromDate, @ToDate, @Reason, @Status)";

            using (SqlConnection con = new SqlConnection(_connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@EmployeeName", leave.EmployeeName);
                cmd.Parameters.AddWithValue("@FromDate", leave.FromDate);
                cmd.Parameters.AddWithValue("@ToDate", leave.ToDate);
                cmd.Parameters.AddWithValue("@Reason", leave.Reason);
                cmd.Parameters.AddWithValue("@Status", "Pending");

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }


        public DataTable GetPayroll()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT FullName, Salary FROM Employee";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.Fill(dt);
            }

            return dt;
        }

    }
}
